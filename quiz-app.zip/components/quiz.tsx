"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, XCircle, RotateCcw } from "lucide-react"

// Quiz questions data
const quizData = [
  {
    question: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correctAnswer: "Paris",
  },
  {
    question: "Which planet is known as the Red Planet?",
    options: ["Earth", "Mars", "Jupiter", "Venus"],
    correctAnswer: "Mars",
  },
  {
    question: "What is the largest mammal in the world?",
    options: ["Elephant", "Giraffe", "Blue Whale", "Polar Bear"],
    correctAnswer: "Blue Whale",
  },
  {
    question: "Which element has the chemical symbol 'O'?",
    options: ["Gold", "Oxygen", "Osmium", "Oganesson"],
    correctAnswer: "Oxygen",
  },
  {
    question: "Who painted the Mona Lisa?",
    options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
    correctAnswer: "Leonardo da Vinci",
  },
]

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState("")
  const [score, setScore] = useState(0)
  const [showFeedback, setShowFeedback] = useState(false)
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    setProgress((currentQuestion / quizData.length) * 100)
  }, [currentQuestion])

  const handleAnswerSelect = (answer: string) => {
    setSelectedAnswer(answer)
  }

  const handleSubmit = () => {
    if (selectedAnswer === "") return

    setShowFeedback(true)

    if (selectedAnswer === quizData[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }
  }

  const handleNextQuestion = () => {
    setSelectedAnswer("")
    setShowFeedback(false)

    if (currentQuestion < quizData.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setQuizCompleted(true)
    }
  }

  const resetQuiz = () => {
    setCurrentQuestion(0)
    setSelectedAnswer("")
    setScore(0)
    setShowFeedback(false)
    setQuizCompleted(false)
    setProgress(0)
  }

  const isCorrect = selectedAnswer === quizData[currentQuestion].correctAnswer

  if (quizCompleted) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Quiz Completed!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center text-2xl font-bold">
            Your Score: {score} / {quizData.length}
          </div>
          <div className="text-center text-lg">
            {score === quizData.length
              ? "Perfect score! Excellent job!"
              : score >= quizData.length / 2
                ? "Good job! You passed the quiz."
                : "Keep practicing. You'll do better next time!"}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={resetQuiz} className="w-full">
            <RotateCcw className="mr-2 h-4 w-4" /> Restart Quiz
          </Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <div className="text-sm text-muted-foreground">
            Question {currentQuestion + 1} of {quizData.length}
          </div>
          <div className="text-sm text-muted-foreground">Score: {score}</div>
        </div>
        <Progress value={progress} className="h-2" />
        <CardTitle className="mt-4">{quizData[currentQuestion].question}</CardTitle>
      </CardHeader>
      <CardContent>
        <RadioGroup value={selectedAnswer} className="space-y-3">
          {quizData[currentQuestion].options.map((option, index) => (
            <div
              key={index}
              className={`
                flex items-center space-x-2 rounded-md border p-3 cursor-pointer
                ${showFeedback && option === quizData[currentQuestion].correctAnswer ? "border-green-500 bg-green-50 dark:bg-green-950/20" : ""}
                ${showFeedback && option === selectedAnswer && !isCorrect ? "border-red-500 bg-red-50 dark:bg-red-950/20" : ""}
                ${!showFeedback && option === selectedAnswer ? "border-primary" : ""}
              `}
              onClick={() => !showFeedback && handleAnswerSelect(option)}
            >
              <RadioGroupItem value={option} id={`option-${index}`} disabled={showFeedback} className="sr-only" />
              <Label htmlFor={`option-${index}`} className="w-full cursor-pointer font-medium">
                {option}
              </Label>
              {showFeedback && option === quizData[currentQuestion].correctAnswer && (
                <CheckCircle className="h-5 w-5 text-green-500" />
              )}
              {showFeedback && option === selectedAnswer && !isCorrect && <XCircle className="h-5 w-5 text-red-500" />}
            </div>
          ))}
        </RadioGroup>

        {showFeedback && (
          <div
            className={`mt-4 p-3 rounded-md ${isCorrect ? "bg-green-50 text-green-700 dark:bg-green-950/20 dark:text-green-400" : "bg-red-50 text-red-700 dark:bg-red-950/20 dark:text-red-400"}`}
          >
            {isCorrect
              ? "Correct! Well done."
              : `Incorrect. The correct answer is ${quizData[currentQuestion].correctAnswer}.`}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {!showFeedback ? (
          <Button onClick={handleSubmit} disabled={selectedAnswer === ""} className="w-full">
            Submit Answer
          </Button>
        ) : (
          <Button onClick={handleNextQuestion} className="w-full">
            {currentQuestion < quizData.length - 1 ? "Next Question" : "See Results"}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
