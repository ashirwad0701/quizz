import Quiz from "@/components/quiz"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4 md:p-24">
      <h1 className="mb-8 text-3xl font-bold text-center">Interactive Quiz</h1>
      <Quiz />
    </main>
  )
}
